-------------------------------------------------------------------------------------------------------------------
Instances for the discrete parallel machine scheduling location problem
Proposed by R. Kramer & A. Kramer in 
"Exact and heuristic methods for the discrete parallel machine scheduling location problem"
-------------------------------------------------------------------------------------------------------------------

In total, 283 instances were randomly generated.

We considered different combinations of n (# of jobs), m (# of machine candidate locations) and p (# of machines), 
with n ∈ {100, 200, 300}, m ∈ {20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240, 260, 280}, and 
p ∈ {2, 3, 5, 7, 10, 15, 20, 30, 40, 50, 75, 100}, such that m < n and p < m. 

The coordinates for the jobs (x_j, y_j) and for the machine candidate locations (x_k, y_k) have been 
randomly generated within a square n X n, and the job processing times have been randomly generated 
between floor(n/10) and floor(n/2), both considering an uniform distribution. 

Then, based on the coordinates of job j and machine candidate location k, we computed the release dates r_jk, 
for every j ∈ J = {1,...,n} and k ∈ M = {1,...,m}, as r_jk = floor((x_j - x_k )^2 + (y_j - y_k )^2). 

-------------------------------------------------------------------------------------------------------------------

The format of each instance file is as given below:

NLocations: Number of machine candidate locations (m)
NMachines: Number of machines (p)
NJobs: Number of jobs (n)
Process: Processing time of jobs (p_j, j = 1...n)
Release: Release dates of jobs on each location given as an n X m matrix (r_jk, j = 1...m, k = 1,...,m)

-------------------------------------------------------------------------------------------------------------------
